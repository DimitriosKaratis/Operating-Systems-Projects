// functions.h
#ifndef FUNCTIONS_H
#define FUNCTIONS_H

// Function declarations
void greet();
int add(int a, int b);

#endif
